
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.event.MouseEvent;
import java.awt.geom.Line2D;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JComponent;

public class JComponentMK extends JComponent implements java.awt.event.MouseListener{
    BufferedImage bufferedImage=null;
    Map<Point, String> textList=null;
    List<Line2D> linesList=null;
    List<Rectangle> rectsList =null;
    List<Rectangle> fillRectsList =null;
    int width=600;
    int height=500;

    public BufferedImage getBufferedImage() {
        return bufferedImage;
    }

    public void setBufferedImage(BufferedImage bufferedImage) {
        this.bufferedImage = bufferedImage;
    }

    public JComponentMK() {
       setSize(width,height);
       addMouseListener(this);
       textList = new HashMap<>();
       linesList = new ArrayList<>();
       rectsList = new ArrayList<>();
       fillRectsList = new ArrayList<>();
       addTexts();
       addLines();
       addRects();
       addFillRects();
       try {
            bufferedImage = javax.imageio.ImageIO.read(JComponentMK.class.getResource("/resources/picture.png"));
        } catch (IOException ex) {
            Logger.getLogger(JComponentMK.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    
    @Override
    public void paintComponent(Graphics graph) {
        Graphics2D graph2=(Graphics2D)graph;
        
        graph2.drawImage(bufferedImage,0,0,width, height,null);
         
        graph2.setColor(Color.red);
        graph2.setFont(new Font(Font.SANS_SERIF,Font.BOLD,16)); 
        for(Map.Entry<Point, String> entry : textList.entrySet()) 
            graph2.drawString(entry.getValue(),entry.getKey().x,entry.getKey().y );
        
        graph2.setColor(Color.black);
        for(Line2D l:linesList)
            graph2.drawLine((int)l.getX1(),(int)l.getY1(),(int)l.getX2(),(int)l.getY2());
            
        graph2.setColor(Color.MAGENTA);
        for(Rectangle r:rectsList)
            graph2.drawRect(r.x,r.y,r.width,r.height);
        
        try {
            BufferedImage imGrafika=javax.imageio.ImageIO.read(JComponentMK.class.getResource("/resources/sloneczko.png"));
            BufferedImage imagePattern = imGrafika.getSubimage(0, 0, 85,75);
            java.awt.TexturePaint texturePattern  = new java.awt.TexturePaint(
                    imagePattern,new java.awt.Rectangle(0,0,100,100));
            graph2.setPaint(texturePattern);
            for(Rectangle r:fillRectsList)
                graph2.fillRect(r.x,r.y,r.width,r.height);
        } catch (IOException ex) {
            Logger.getLogger(JComponentMK.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    private void addTexts() {
       textList.put(new Point(350,300),"Mariusz");
       textList.put(new Point(150,200),"Krzyzowski");
       textList.put(new Point(400,100),"KLIKAJ MYSZA!");
    }

    private void addLines() {
        linesList.add(new Line2D.Double(25,25,100,100));
        linesList.add(new Line2D.Double(55,25,200,300));
        linesList.add(new Line2D.Double(175,75,10,100));
    }

    private void addRects() {
       rectsList.add(new Rectangle(200,200,30,30));
       rectsList.add(new Rectangle(200,300,12,20));
       rectsList.add(new Rectangle(300,200,50,50)); }

    private void addFillRects() {
        fillRectsList.add(new Rectangle(400,150,50,50));
        fillRectsList.add(new Rectangle(500,330,60,90));
        fillRectsList.add(new Rectangle(300,430,40,30));
        
    }
    
    @Override
    public void mouseClicked(MouseEvent me) {
        Random rand = new Random();
        int i,j; 
        
        switch(rand.nextInt(4)) {
            case 0: 
                 textList.put(new Point(rand.nextInt(550),rand.nextInt(480)),"Tekst"); break;
            case 1:     
                 linesList.add(new Line2D.Double(i=rand.nextInt(600),j=rand.nextInt(500),rand.nextInt(600-i),rand.nextInt(500-j))); break;
            case 2:
                 rectsList.add(new Rectangle(i=rand.nextInt(600),j=rand.nextInt(500),rand.nextInt(600-i),rand.nextInt(500-j))); break;
            case 3:
                 fillRectsList.add(new Rectangle(i=rand.nextInt(600),j=rand.nextInt(500),rand.nextInt(600-i)/2,rand.nextInt(500-j)/2)); break;
        }
      this.repaint();
    }

    @Override
    public void mousePressed(MouseEvent me) {
    }

    @Override
    public void mouseReleased(MouseEvent me) {
    }

    @Override
    public void mouseEntered(MouseEvent me) {
    }

    @Override
    public void mouseExited(MouseEvent me) {
    }
    
    @Override
    public Dimension getMinimumSize() {
        return new Dimension(600,500);
    }
    
    @Override
    public Dimension getPreferredSize() {
        return new Dimension(600,500);
    }
    @Override
    public Dimension getMaximumSize() {
        return new Dimension(600,500);
    }
   
}


   