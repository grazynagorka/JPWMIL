package arkanoid;

import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;

public class AnimationExplosion {
    private int x = 0;
    private int y = 0;
    private final int frameWidth = 128;
    private final int frameHeight = 128;
    private int delayActual = 10;
    private final int delay = 1;
    private int keyFrame = 0;
    private final int maxFrame = 5;
    private final BufferedImage explosionImage;
    public boolean isFinished = false;

    public AnimationExplosion(int x, int y, BufferedImage explosionImage)  {
        this.x = x;
        this.y = y;
        this.explosionImage = explosionImage;
    }
    
    public void action() {
        if(delayActual > 0)
            delayActual--;
        else {
            delayActual = delay;
            
            if(keyFrame < maxFrame)
                keyFrame++;
            else
                isFinished = true;
        }
    }
    
    public void paintObject(Graphics graph) {
        if(!isFinished) {
            Graphics graphTemp = graph.create();
            Graphics2D graph2D = (Graphics2D)graphTemp;
            BufferedImage actualFrame = explosionImage.getSubimage(keyFrame * frameWidth, 0, frameWidth, frameHeight);
            graph2D.drawImage(actualFrame, x, y, null); }
    }    
}