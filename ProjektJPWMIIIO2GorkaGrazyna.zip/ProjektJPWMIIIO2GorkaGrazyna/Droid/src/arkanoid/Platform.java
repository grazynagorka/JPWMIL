package arkanoid;

import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.image.BufferedImage;
import javax.swing.JOptionPane;

public class Platform {
    public static Platform platform;
    private final BufferedImage platformImage;
    int x = 0;
    int y = 0;
    int width = 100;
    int height = 100;
    
    private boolean isShooting = false;

    public Platform(int x, int y, BufferedImage bufferedImage){
        this.x = (x / 2) - (width / 2);
        this.y = y - height - 20;
        this.platformImage = bufferedImage;
        platform = this;
    }
    
    private int i = 0;
    public void paintObject(Graphics graph){
        Graphics graphTemp = graph.create();
        Graphics2D graph2D = (Graphics2D)graphTemp;
        graph2D.drawImage(platformImage, x, y, width, height, null);
        if(isShooting) {
            i++;
            graph2D.setPaint(Color.WHITE);
            
            for(int i=0; i<21; i++) {
                graph2D.fillOval(x + width / 2 -10, i*30, 20, 20);
            }
            if(i >= 5)  {
                isShooting = false;
                i = 0;
            }
        }
    }
    
    public void action(KeyEvent e) {
        switch(e.getKeyCode()) {                  
            case KeyEvent.VK_LEFT:
                if(x - 10 >= 0)
                    x -= 10;
                break;
                        
            case KeyEvent.VK_RIGHT:
                if(x + 10 + width <= JComponentGG.width)
                    x += 10;
                break;
                            
            case KeyEvent.VK_SPACE:
                shoot();
                break;
        }
    }
    
    private void shoot(){
        isShooting = true;
        JComponentGG.component.trialShoot(x);
        if(JComponentGG.component.score<=-10)
            JOptionPane.showMessageDialog(JOptionPane.getRootFrame(), "Przegrales :(");
        
        if(JComponentGG.component.score>=25)
            JOptionPane.showMessageDialog(JOptionPane.getRootFrame(), "Wygrales :)");
    }
}