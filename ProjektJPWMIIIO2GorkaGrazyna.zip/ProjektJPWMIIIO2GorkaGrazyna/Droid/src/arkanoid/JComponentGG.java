package arkanoid;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.awt.image.BufferedImage;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import javax.imageio.ImageIO;
import javax.swing.JComponent;
import javax.swing.Timer;
import java.io.BufferedInputStream;
import java.io.IOException;
import java.util.Iterator;
import javax.sound.sampled.*;

public class JComponentGG extends JComponent implements java.awt.event.ActionListener, java.awt.event.KeyListener {
    public static final int width = 1100;
    public static final int height = 700;
    public static JComponentGG component;
    private BufferedImage backgroundImage; 
    private BufferedImage brickImage;
    private BufferedImage platformImage;
    private BufferedImage explosionImage;
    private Platform platform;
    private Timer timer;
    private List<Brick> bricks = new ArrayList<>();
    private List<AnimationExplosion> explosions = new ArrayList<>();
    public int score;
    public static boolean isSound = false;
    
    public static int x,y;
    public String text;
    public int orientation;
    List<AnimationText> animationShapesList = new ArrayList<>();
    
    public JComponentGG() { 
      this.setFocusable(true);
      addKeyListener(this);
      
        try {
            backgroundImage = ImageIO.read(getClass().getResource("resources/images/bg.jpg"));
            platformImage = ImageIO.read(getClass().getResource("resources/images/platform.png"));
            brickImage = ImageIO.read(getClass().getResource("resources/images/brick.png"));
            explosionImage = ImageIO.read(getClass().getResource("resources/images/explosion.png"));
            setSize(backgroundImage.getWidth(), backgroundImage.getHeight());
            
            platform = new Platform(width, height, platformImage);
            
            score=0;
            timer = new Timer(20, this);
            timer.start();
            
           if(!isSound) { 
            Clip clip = AudioSystem.getClip();
            AudioInputStream audioInputStream = AudioSystem.getAudioInputStream(new BufferedInputStream(getClass().getClassLoader().getResourceAsStream("arkanoid/resources/sounds/music.wav")));
            clip.open(audioInputStream);
            clip.loop(Clip.LOOP_CONTINUOUSLY);
            clip.start();
            isSound = true; }
        } 
        catch (IOException | LineUnavailableException | UnsupportedAudioFileException ex)  {}
        component = this;
    }
    
    @Override
    public void paintComponent(Graphics g) {
        Graphics2D g2 = (Graphics2D)g; 
        Dimension dimensions = getSize();
        g2.drawImage(backgroundImage, 0, 0, (int)dimensions.getWidth(), (int)dimensions.getHeight(), null);
        
        g2.setFont(new Font("serif", Font.BOLD, 25));
        g2.setColor(Color.white);
        g2.drawString("   " +score+" pkt", 130,45);
        
      if(score>-10 && score<25)  {
        for(Brick brick : bricks)
            brick.paintObject(g);
        
        for(AnimationExplosion explosion : explosions)
            explosion.paintObject(g);
        
        platform.paintObject(g);
      }
      else {
        AnimationText animationShape = null;
        try {
            animationShape = new AnimationText("Grazyna Gorka", 150, 150, 0);
        } catch (Exception e) { }
        
        animationShapesList.add(animationShape);
        Iterator<AnimationText> animationShapeIterator = animationShapesList.iterator();
        while (animationShapeIterator.hasNext()) {
            animationShapeIterator.next().action(g);
        }
      }
    }
    
    @Override
    public void actionPerformed(ActionEvent e) {   
        generateBrick();
        List<Brick> toRemoveBricks = new ArrayList<>();
        List<AnimationExplosion> destroyedBricks = new ArrayList<>();
        
        for(Brick brick : bricks)  {
            brick.action();
            if(brick.y >= height - Brick.height) {
                score-=1;
                toRemoveBricks.add(brick);
            }
            if(brick.destroyed) {
                addExplosion(brick.x, brick.y);
                toRemoveBricks.add(brick);
            }
        }
        
        for(Brick brick : toRemoveBricks) {
            bricks.remove(brick);
            brick = null;
        }
        
        for(AnimationExplosion explosion : explosions) { 
            if(explosion.isFinished)
                destroyedBricks.add(explosion);
            else
                explosion.action();
        }
        
        for(AnimationExplosion explosion: destroyedBricks) {
            explosions.remove(explosion);
            explosion = null;
        }
        destroyedBricks.clear();
        toRemoveBricks.clear();
        
        repaint();
    }
    
    public static int iteration = 0;
    private void generateBrick() {
        iteration++; 
        if(iteration==100) {
        Random random = new Random();
        int xRandom = random.nextInt(width - Brick.width);
        Brick brick = new Brick(xRandom, 0, brickImage);
        bricks.add(brick); 
        iteration = 0;}    
    }
    
    public void trialShoot(int x) {
        List<Brick> removedBricks = new ArrayList<>();
        boolean success = false;
        for(Brick brick : bricks) {
            if(x > brick.x - Brick.width / 2 && x < brick.x + Brick.width / 2) {
                removedBricks.add(brick);
                score+=5;
                success=true;
                addExplosion(brick.x, brick.y);
            }
        }
        if(!success) score-=2;
        for(Brick brick : removedBricks) {
            bricks.remove(brick);
            brick = null;
        }
        removedBricks.clear();
    }
    
    private void addExplosion(int x, int y){
        AnimationExplosion explosion = new AnimationExplosion(x, y, explosionImage);
        explosions.add(explosion);
        playSound();
    }
    
    private void playSound() {
        try {
            Clip clip = AudioSystem.getClip();
            AudioInputStream audioInputStream = AudioSystem.getAudioInputStream(new BufferedInputStream(getClass().getClassLoader().getResourceAsStream("arkanoid/resources/sounds/explosion.wav")));
            clip.open(audioInputStream);
            clip.start();
        }
        catch (UnsupportedAudioFileException | IOException | LineUnavailableException ex) {}
    }
    
    @Override
    public void keyTyped(KeyEvent ke) {
    }

    @Override
    public void keyPressed(KeyEvent ke) {
      platform.action(ke);
      repaint();
    }

    @Override
    public void keyReleased(KeyEvent ke) {
    }
}