package arkanoid;

import java.awt.*;
import java.awt.image.BufferedImage;

public class Brick {
    public int x = 0;
    public int y = 0;
    public static final int width = 80;
    public static final int height = 80;
    BufferedImage brickImage;
    public boolean destroyed = false;

    public Brick(int x, int y, BufferedImage bufferedImage) {
        this.x = x;
        this.y = y;
        this.brickImage = bufferedImage;
    }
    
    public void action(){
            y++;
    }
    
    public void paintObject(Graphics graph){
        Graphics graphTemp = graph.create();
        Graphics2D graph2D = (Graphics2D)graphTemp;
        graph2D.drawImage(brickImage, x, y, width, height, null);
    }
}