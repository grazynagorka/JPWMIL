package arkanoid;

import java.awt.*;

public class AnimationText extends JComponentGG {

    public AnimationText(String text, int x, int y, int orientation) throws Exception {
        this.x = x;
        this.y = y;
        this.text = text;
        this.orientation = orientation;
    }

    public void paintObject(Graphics graphics) {
        Graphics graphicsTemp = graphics.create();
        Graphics2D graphics2D = (Graphics2D) graphicsTemp;
        graphics2D.setFont(new Font("Serif", Font.PLAIN, 20));
        graphics2D.setColor(Color.red);
        graphics2D.rotate(Math.toRadians(orientation), x, y);
        graphics2D.translate(x, 0);
        graphics2D.drawString(text, x, y);
    }
    
    public void action(Graphics graphics) {
        orientation = orientation + 8;
        if (x > 600) 
            x = 0;
        else
            x +=8;
        paintObject(graphics);
    }
}