
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.geom.AffineTransform;
import java.io.IOException;
import java.util.ArrayList;
import javax.imageio.ImageIO;


public class AnimationRaster extends JComponentGG {
    public AnimationRaster(int x, int y, int width, int height, int delay, int orientation) throws Exception {
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
        this.delay = delay;
        this.delayActual = delay;
        this.orientation = orientation;

        bufferedImageList = new ArrayList<>();
        try {
            bufferedImageList.add(ImageIO.read(JComponentGG.class.getResource("/resources/1.png")));
            bufferedImageList.add(ImageIO.read(JComponentGG.class.getResource("/resources/2.png")));
             bufferedImageList.add(ImageIO.read(JComponentGG.class.getResource("/resources/3.png")));
             bufferedImageList.add(ImageIO.read(JComponentGG.class.getResource("/resources/4.png")));
             bufferedImageList.add(ImageIO.read(JComponentGG.class.getResource("/resources/5.png")));
             bufferedImageList.add(ImageIO.read(JComponentGG.class.getResource("/resources/6.png")));
             bufferedImageList.add(ImageIO.read(JComponentGG.class.getResource("/resources/7.png")));
             bufferedImageList.add(ImageIO.read(JComponentGG.class.getResource("/resources/8.png")));
             bufferedImageList.add(ImageIO.read(JComponentGG.class.getResource("/resources/9.png")));
           
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void paintObject(Graphics graphics, int i) {
        Graphics graphicsTemp = graphics.create();
        Graphics2D g2d = (Graphics2D) graphicsTemp;
        graphicsTemp.setColor(Color.BLACK);
        affineTransform = new AffineTransform();
        affineTransform.rotate(Math.toRadians(orientation), x, y);
        affineTransform.translate(x, y);
        g2d.drawImage(bufferedImageList.get(i), affineTransform, null);

    }
}
