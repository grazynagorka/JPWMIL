import java.awt.*;

public class AnimationShape extends JComponentGG {

    public AnimationShape(String text, int x, int y, int orientation) throws Exception {
        this.x = x;
        this.y = y;
        this.text = text;
        this.orientation = orientation;
    }

    public void paintObject(Graphics graphics) {
        Graphics graphicsTemp = graphics.create();
        Graphics2D graphics2D = (Graphics2D) graphicsTemp;
        graphics2D.setFont(new Font("Serif", Font.PLAIN, 20));
        graphics2D.setColor(Color.white);
        graphics2D.rotate(Math.toRadians(orientation), x, y);
        graphics2D.translate(x, 0);
        graphics2D.drawString(text, x, y);
    }

    public void action() {
        orientation = orientation + 8;
        if (x > 400) {
            x = 0;
        } else {
            x = x + 8;
        }
    }
}
