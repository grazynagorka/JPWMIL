import javax.imageio.ImageIO;
import javax.swing.*;
import javax.swing.Timer;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.geom.AffineTransform;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.*;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;



public class JComponentGG extends JComponent implements ActionListener {

    int x;
    int y;
    int delay;
    int orientation;
    int delayActual;
    String text;
    AffineTransform affineTransform;
    List<AnimationRaster> animationRasterList = new ArrayList<>();
    List<AnimationShape> animationShapesList = new ArrayList<>();
    BufferedImage BackgroundbufferedImage;
    List<BufferedImage> bufferedImageList;
    int width = 800;
    int height = 600;
    int imageWidth = 0;
    Timer timer;

    public JComponentGG() throws Exception {
        setSize(width, height);
        try {
            BackgroundbufferedImage = ImageIO.read(JComponentGG.class.getResource("/resources/background.jpg"));
        } catch (IOException e) {
            e.printStackTrace();
        }
        timer = new Timer(150, this);
        timer.start();

    }

    public void paintComponent(Graphics graphics) {
        Graphics2D graphics2D = (Graphics2D) graphics;
        graphics2D.drawImage(BackgroundbufferedImage, 0, 0, width, height, null);

        AnimationShape animationShape = null;
        try {
            animationShape = new AnimationShape("Gorka Grazyna", 150, 150, 0);
        } catch (Exception e) {
            e.printStackTrace();
        }
        animationShapesList.add(animationShape);
        Iterator<AnimationShape> animationShapeIterator = animationShapesList.iterator();
        while (animationShapeIterator.hasNext()) {
            animationShapeIterator.next().paintObject(graphics);
        }

        try {
            AnimationRaster animationRaster = new AnimationRaster(imageWidth, 0, 0, 0, 0, 0);
            animationRasterList.add(animationRaster);
            if (imageWidth >= 800) {
                imageWidth = 0;
            } else {
                imageWidth += 57;
            }

        } catch (Exception ex) {
            Logger.getLogger(MyFrame.class.getName()).log(Level.SEVERE, null, ex);
        }
        int i = 0;
        java.util.Iterator<AnimationRaster> rasterAnimationIterator = animationRasterList.iterator();
        while (rasterAnimationIterator.hasNext()) {
            if (i < 9) {
                graphics2D.setColor(Color.CYAN);
                graphics2D.fillRect(0, 0, 800, 99);
                rasterAnimationIterator.next().paintObject(graphics, i);
                i++;
                if (i == 9) {
                    i = 0;
                }
            }
        }

    }

    @Override
    public void actionPerformed(ActionEvent e) {
        Iterator<AnimationRaster> animationRasterIterator = animationRasterList.iterator();
        while (animationRasterIterator.hasNext()) {
            animationRasterIterator.next();
        }

        Iterator<AnimationShape> animationShapeIterator = animationShapesList.iterator();
        while (animationShapeIterator.hasNext()) {
            animationShapeIterator.next().action();
        }

        repaint();
    }
      @Override                                  
    public Dimension getMinimumSize() {
        return new Dimension(width,height);
    }
    
    @Override
    public Dimension getPreferredSize() {
        return new Dimension(width,height);
    }
    @Override
    public Dimension getMaximumSize() {
        return new Dimension(width,height);
    }
}