/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package zadanie;

import javafx.application.Application;
import static javafx.application.Application.launch;
import javafx.geometry.Point3D;
import javafx.scene.AmbientLight;
import javafx.scene.PerspectiveCamera;
import javafx.scene.PointLight;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.scene.paint.PhongMaterial;
import javafx.scene.shape.Cylinder;
import javafx.scene.shape.MeshView;
import javafx.scene.shape.Sphere;
import javafx.scene.shape.TriangleMesh;
import javafx.scene.text.Text;
import javafx.stage.Stage;

/**
 *
 * @author Admin
 */
public class NewFXMain extends Application {
    
    public void start(Stage primaryStage) {
    //kamera
        PerspectiveCamera cameraPerspective = new PerspectiveCamera(true);
        cameraPerspective.setNearClip(0.4); cameraPerspective.setFarClip(900.0);
        cameraPerspective.setTranslateZ(-750);
        cameraPerspective.setTranslateX(200);
        cameraPerspective.setTranslateY(100);
        
   //plaszczyzna     
      float[] points = {-200,-200,200, -100,-200,200, 0,-200,100, 100,-200,100, 200,-200,200, -200,-100,100, -100,-100,-100, 0,-100,100, 100,-100,-100, 200,-100,100,
                          -200,100,100, -100,100,0, 0,100,-200, 100,100,0, 200,100,100, 
                          -200,100,200, -100,100,-200, 0,100,100, 100,100,-100, 200,100,200,
                           -200,200,200, -100,200,200, 0,200,100, 100,200,100, 200,200,100};
        int[] faces = {5,5,1,1,0,0,
                        5,5,6,6,1,1,
                        6,6,2,2,1,1,
                        6,6,7,7,2,2,
                        7,7,3,3,2,2,
                        7,7,8,8,3,3,
                        8,8,4,4,3,3,
                        8,8,9,9,4,4};
        float[] textureCoords = { 0.0f, 0.0f, 0.25f, 0.0f, 0.5f, 0.0f, 0.75f,0.0f, 1.0f,0.0f, 
            0.0f, 0.25f, 0.25f, 0.25f, 0.5f,0.25f, 0.75f,0.25f, 1.0f, 0.25f,
            0.0f,0.5f,0.25f, 0.5f, 0.5f,0.5f,0.75f,0.5f,1.0f,0.5f,
            0.0f,0.75f,0.25f,0.75f,0.5f,0.75f,0.75f,0.75f,1.0f,0.75f,
            0.0f, 1.0f,0.25f,1.0f,0.5f,1.0f,0.75f,1.0f,1.0f,1.0f};                

        TriangleMesh triangleMesh = new TriangleMesh();
        triangleMesh.getPoints().addAll(points);
        triangleMesh.getTexCoords().addAll(textureCoords);
        triangleMesh.getFaces().addAll(faces);
        MeshView meshView = new MeshView(triangleMesh);
        PhongMaterial materialMesh = new PhongMaterial();
        Image imageDiffuse = new Image(NewFXMain.class.getResource("gwiazdki.jpg").toString(),1024,1024,false,false);
        materialMesh.setDiffuseMap(imageDiffuse);
        meshView.setMaterial(materialMesh);
    //napis    
        Text text = new Text("Gorka Grazyna grupa IO2");
        text.setTranslateX(50);
        text.setTranslateY(-240);
    //swiatlo otoczenia    
        AmbientLight ambientLight = new AmbientLight();
        ambientLight.setColor(Color.color(0.3,0.3,0.3));
    //swiatlo punktowe
        PointLight pointLight1 = new PointLight();
        pointLight1.setColor(Color.AQUA);
        pointLight1.setTranslateZ(-20);
        pointLight1.setTranslateX(-20);

//kula
        Sphere sphere = new Sphere(70,50);
        sphere.setTranslateX(-150);
        sphere.setTranslateY(-240);
        sphere.setTranslateZ(100);
        PhongMaterial material = new PhongMaterial();
        imageDiffuse = new Image(NewFXMain.class.getResource("domek.jpg").toString(),1024,1024,false,false);
        material.setDiffuseMap(imageDiffuse);
        sphere.setMaterial(material);
//walec        
        Cylinder cylinder = new Cylinder(140,200,100);
        cylinder.setTranslateX(100);
        cylinder.setTranslateY(15);
        cylinder.setTranslateZ(190);
        cylinder.setRotationAxis(new Point3D(10,10,10));
        imageDiffuse = new Image(NewFXMain.class.getResource("laka.jpg").toString(),1024,1024,false,false);
        PhongMaterial materialCylinder = new PhongMaterial();
        materialCylinder.setDiffuseMap(imageDiffuse);
        cylinder.setMaterial(materialCylinder);
        
       
        
        StackPane root = new StackPane();
        root.getChildren().addAll(text,sphere,cylinder,meshView,ambientLight,pointLight1);
        
        Scene scene = new Scene(root, 400,400, true);
        scene.setCamera(cameraPerspective);
        scene.setFill(Color.CHOCOLATE);
        
        primaryStage.setTitle("Gorka Grazyna");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }
    
}
